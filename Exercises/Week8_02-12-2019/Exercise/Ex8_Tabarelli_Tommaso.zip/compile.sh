gfortran Ex8_Tommaso_Tabarelli_CODE.f90 Debug.f90 -llapack -o Ex8_Tommaso_Tabarelli_CODE.exe -Wunused-variable -fsanitize=address
sh .clear_debug
