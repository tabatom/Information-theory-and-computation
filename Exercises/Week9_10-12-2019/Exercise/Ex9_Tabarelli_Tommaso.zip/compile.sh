gfortran Ex9_Tommaso_Tabarelli_CODE.f90 Debug.f90 my_math.f90 -llapack -lfftw3 -lm -o Ex9_Tommaso_Tabarelli_CODE.exe -Wunused-variable #-fsanitize=address
sh .clear_debug
