python Ex6_Tabarelli_Tommaso_CODE.py 5 15 3 10 10000 4
