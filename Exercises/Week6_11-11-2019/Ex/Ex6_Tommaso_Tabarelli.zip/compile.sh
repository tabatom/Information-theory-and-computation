gfortran Ex6_Tommaso_Tabarelli_CODE.f90 Debug.f90 Hermite.f90 Factorial.f90 -llapack -o Ex6_Tommaso_Tabarelli_CODE.exe -Wunused-variable -fsanitize=address
source .clear_debug
