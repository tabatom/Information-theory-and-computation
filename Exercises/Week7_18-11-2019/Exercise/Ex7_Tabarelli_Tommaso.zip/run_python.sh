#python Ex7_Tommaso_Tabarelli_CODE.py L_lim k_split T_tot time_steps gnuplot_steps
python Ex7_Tommaso_Tabarelli_CODE.py 20 400 1 200 200
