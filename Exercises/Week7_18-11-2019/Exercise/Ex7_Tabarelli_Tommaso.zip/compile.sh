gfortran Ex7_Tommaso_Tabarelli_CODE.f90 Debug.f90 Hermite.f90 Factorial.f90 -llapack -lfftw3 -lm -o Ex7_Tommaso_Tabarelli_CODE.exe -Wunused-variable -fsanitize=address
sh .clear_debug
